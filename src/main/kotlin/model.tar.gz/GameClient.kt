import model.GameClientPermissionLayer
import model.controller.GameController
import model.controller.LobbyController
import model.state.client.GameState
import model.state.client.LobbyState
import model.state.client.OnStateChangeListener
import java.io.Closeable
import java.net.InetSocketAddress

class GameClient(
    private val username: String,
    address: InetSocketAddress = InetSocketAddress("239.192.0.4", 9192),
    private val onStateChangeListener: OnStateChangeListener
) : Closeable {
    // ensures correct disposal of state machine nodes
    private var permissionLayer = GameClientPermissionLayer(address)

    fun lobbyController(): LobbyController {
        if (permissionLayer.state !is LobbyState) {
            throw IllegalStateException("could not able to get lobby controller not from lobby")
        }
        return permissionLayer.state as LobbyController
    }

    fun gameController(): GameController {
        if (permissionLayer.state !is GameState) {
            throw IllegalStateException("could not able to get game controller not from game")
        }
        return permissionLayer.state as GameController
    }

    override fun close() {
        permissionLayer.close()
    }
}