package model.controller

interface Controller {
}