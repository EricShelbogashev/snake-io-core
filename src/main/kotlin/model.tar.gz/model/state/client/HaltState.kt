package model.state.client

import model.Context

class HaltState(context: Context) : State(context){
}