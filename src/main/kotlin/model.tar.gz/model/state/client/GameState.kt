package model.state.client

import me.ippolitov.fit.snakes.SnakesProto
import me.ippolitov.fit.snakes.SnakesProto.Direction
import me.ippolitov.fit.snakes.SnakesProto.GamePlayer
import me.ippolitov.fit.snakes.SnakesProto.GameState.Snake
import me.ippolitov.fit.snakes.SnakesProto.NodeRole
import model.Context
import model.controller.GameController
import model.controller.OnGameStateChangeListener
import model.state.game.GameConfig
import java.net.DatagramPacket
import java.net.InetSocketAddress

abstract class GameState(protected val context: Context) : State(context),
    GameController {
    private var onGameStateChangeListener: OnGameStateChangeListener? = null

    override fun leaveGame() {
        onGameStateChangeListener = null
    }

    override fun setOnGameStateChangeListener(listener: OnGameStateChangeListener) {
        this.onGameStateChangeListener = listener
    }

    /**
     * Должен вызываться один раз в config.stateDelayMs, если Master
     * и с допустимой задержкой до 0.8*config.stateDelayMs, если нет.
     * */
    protected open fun updateGameState(state: SnakesProto.GameState) {
        onGameStateChangeListener?.updateState(state)
    }

    protected class Publisher(private val context: Context, playerId: Int) {
        private var msgSeq = Long.MIN_VALUE
        private val senderId: Int

        init {
            this.senderId = playerId
        }

        private fun send(packet: DatagramPacket) {
            context.outputSocket.send(packet)
        }

        private fun address(ip: String, port: Int): InetSocketAddress {
            return InetSocketAddress(ip, port)
        }

        fun ping(ip: String, port: Int) {
            val address = address(ip, port)
            val ping = SnakesProto.GameMessage.PingMsg.newBuilder().build()
            val message = SnakesProto.GameMessage.newBuilder()
                .setPing(ping)
                .setMsgSeq(msgSeq++)
                .setSenderId(senderId)
                .build()
            val data = message.toByteArray()
            val packet = DatagramPacket(data, 0, data.size, address)
            send(packet)
        }

        fun steer(ip: String, port: Int, direction: Direction) {
            val address = address(ip, port)
            val steer = SnakesProto.GameMessage.SteerMsg.newBuilder()
                .setDirection(direction)
                .build()
            val message = SnakesProto.GameMessage.newBuilder()
                .setSteer(steer)
                .setMsgSeq(msgSeq++)
                .setSenderId(senderId)
                .build()
            val data = message.toByteArray()
            val packet = DatagramPacket(data, 0, data.size, address)
            send(packet)
        }

        fun ack(ip: String, port: Int, receiverId: Int) {
            val address = address(ip, port)
            val ack = SnakesProto.GameMessage.AckMsg.newBuilder().build()
            val message = SnakesProto.GameMessage.newBuilder()
                .setAck(ack)
                .setMsgSeq(msgSeq++)
                .setSenderId(senderId)
                .setReceiverId(receiverId)
                .build()
            val data = message.toByteArray()
            val packet = DatagramPacket(data, 0, data.size, address)
            send(packet)
        }

        fun announcement(
            ip: String,
            port: Int,
            config: GameConfig,
            players: Array<GamePlayer.Builder>,
            canJoin: Boolean
        ) {
            val address = address(ip, port)

            val protoPlayers = Mapper.toGamePlayersBuilder(players)
            val protoConfig = Mapper.toGameConfigBuilder(config)
            val gameAnnouncementBuilder = SnakesProto.GameAnnouncement.newBuilder()
                .setPlayers(protoPlayers)
                .setConfig(protoConfig)
                .setCanJoin(canJoin)
                .setGameName(config.gameName)

            val announcementMsg = SnakesProto.GameMessage.AnnouncementMsg.newBuilder()
                .setGames(0, gameAnnouncementBuilder)
                .build()

            val message = SnakesProto.GameMessage.newBuilder()
                .setAnnouncement(announcementMsg)
                .setMsgSeq(msgSeq++)
                .setSenderId(senderId)
                .build()
            val data = message.toByteArray()
            val packet = DatagramPacket(data, 0, data.size, address)
            send(packet)
        }

        fun discover(ip: String, port: Int) {
            val address = address(ip, port)
            val discover = SnakesProto.GameMessage.DiscoverMsg.newBuilder().build()
            val message = SnakesProto.GameMessage.newBuilder()
                .setDiscover(discover)
                .setMsgSeq(msgSeq++)
                .setSenderId(senderId)
                .build()
            val data = message.toByteArray()
            val packet = DatagramPacket(data, 0, data.size, address)
            send(packet)
        }

        fun join(ip: String, port: Int, playerName: String, gameName: String) {
            return join(ip, port, playerName, gameName, NodeRole.NORMAL)
        }

        fun view(ip: String, port: Int, playerName: String, gameName: String) {
            return join(ip, port, playerName, gameName, NodeRole.VIEWER)
        }

        private fun join(ip: String, port: Int, playerName: String, gameName: String, role: NodeRole) {
            val address = address(ip, port)
            val join = SnakesProto.GameMessage.JoinMsg.newBuilder()
                .setGameName(gameName)
                .setPlayerName(playerName)
                .setPlayerType(SnakesProto.PlayerType.HUMAN)
                .setRequestedRole(role)
                .build()

            val message = SnakesProto.GameMessage.newBuilder()
                .setJoin(join)
                .setMsgSeq(msgSeq++)
                .setSenderId(senderId)
                .build()
            val data = message.toByteArray()
            val packet = DatagramPacket(data, 0, data.size, address)
            send(packet)
        }

        fun error(ip: String, port: Int, message: String) {
            val address = address(ip, port)
            val error = SnakesProto.GameMessage.ErrorMsg.newBuilder()
                .setErrorMessage(message)
                .build()
            val protoMessage = SnakesProto.GameMessage.newBuilder()
                .setError(error)
                .setMsgSeq(msgSeq++)
                .setSenderId(senderId)
                .build()
            val data = protoMessage.toByteArray()
            val packet = DatagramPacket(data, 0, data.size, address)
            send(packet)
        }

        fun roleChange(ip: String, port: Int, receiverId: Int, senderRole: NodeRole?, receiverRole: NodeRole?) {
            if (senderRole == null && receiverRole == null) {
                throw IllegalArgumentException("хотя бы одно поле из {senderRole, receiverRole} должно быть заполненно")
            }

            val address = address(ip, port)
            val roleChangeMsgBuilder = SnakesProto.GameMessage.RoleChangeMsg.newBuilder()
            if (senderRole != null) {
                roleChangeMsgBuilder.setSenderRole(senderRole)
            }
            if (receiverRole != null) {
                roleChangeMsgBuilder.setReceiverRole(receiverRole)
            }
            val protoMessage = SnakesProto.GameMessage.newBuilder()
                .setRoleChange(roleChangeMsgBuilder)
                .setMsgSeq(msgSeq++)
                .setSenderId(senderId)
                .setReceiverId(receiverId)
                .build()
            val data = protoMessage.toByteArray()
            val packet = DatagramPacket(data, 0, data.size, address)
            send(packet)
        }

        fun state(
            ip: String,
            port: Int,
            gameStateNum: Int,
            snakes: Array<Snake.Builder>,
            players: Array<GamePlayer.Builder>,
            food: Array<SnakesProto.GameState.Coord.Builder>
        ) {
            val address = address(ip, port)

            val state = SnakesProto.GameState.newBuilder()
                .setStateOrder(gameStateNum)

            snakes.forEach(state.snakesBuilderList::add)
            food.forEach(state.foodsBuilderList::add)

            val protoPlayers = SnakesProto.GamePlayers.newBuilder()
            players.forEach(protoPlayers.playersBuilderList::add)
            state.setPlayers(protoPlayers)

            val stateMsg = SnakesProto.GameMessage.StateMsg.newBuilder()
                .setState(state)
                .build()

            val protoMessage = SnakesProto.GameMessage.newBuilder()
                .setState(stateMsg)
                .setMsgSeq(msgSeq++)
                .setSenderId(senderId)
                .build()

            val data = protoMessage.toByteArray()
            val packet = DatagramPacket(data, 0, data.size, address)
            send(packet)
        }
    }
}