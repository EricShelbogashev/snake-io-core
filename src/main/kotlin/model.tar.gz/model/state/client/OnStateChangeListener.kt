package model.state.client

interface OnStateChangeListener {
    fun handleState(state: State)
}