package model.state.game.engine

enum class Direction {
    UP, DOWN, LEFT, RIGHT
}